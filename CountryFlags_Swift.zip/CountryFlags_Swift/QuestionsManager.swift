//
//  QuestionsManager.swift
//  CountryFlags
//
//  Created by Raghavendra Jayaramegowda on 12/12/15.
//  Copyright © 2015 Raghavendra Jayaramegowda. All rights reserved.
//

import UIKit
class QuestionModel {
    var countryName: String = ""
    var fileName: String = ""
    init(fileName: String) {
        self.fileName = fileName
        self.countryName = QuestionModel.extractCountryNameFromFileName(fileName)
    }
    //description function
    func description() -> String {
        return "\(self.countryName) --- \(self.fileName)"
    }
    //This function extracts the country name from file name using NSRegularExpression
    class func extractCountryNameFromFileName(fileName: String) -> String {
        if fileName == "" {
            return ""
        }
        
        let regex:NSRegularExpression?
        do {
            regex = try NSRegularExpression(pattern: "-(.*)\\.png", options: NSRegularExpressionOptions.CaseInsensitive)
        } catch {
            NSLog("Error extractCountryNameFromFileName: %@: %@", fileName)
            return ""
        }
        let checkResult: NSTextCheckingResult = regex!.firstMatchInString(fileName, options: NSMatchingOptions(rawValue: 0), range: NSMakeRange(0, fileName.characters.count))!
        //if search range is empty report error
        let foundRange: NSRange = checkResult.rangeAtIndex(0)
        if foundRange.length == 0{
            NSLog("Range is empty extractCountryNameFromFileName: %@", fileName)
            return ""
        }

        let location = foundRange.location + 1
        let length = foundRange.length - 5//-5, because we do not what the unwanted characters that follows the file name
        let foundString: String = (fileName as NSString).substringWithRange(NSMakeRange(location, length))
        //remove any _ or empty characters from the found string
        return foundString.stringByReplacingOccurrencesOfString("_", withString: " ").stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
    }
}
class QuestionsManager {
    var questions: [QuestionModel] = []
    
    static let sharedInstance: QuestionsManager  = QuestionsManager()
    
    func loadQuestionsData() {
        let resourcePath: NSString = NSBundle.mainBundle().resourcePath!
        let flagsPath: String = resourcePath.stringByAppendingPathComponent("Flags")

        var directoryContents: [String] = []
        do{
            directoryContents = try NSFileManager.defaultManager().contentsOfDirectoryAtPath(flagsPath)
        }catch{
            
        }
        var questions: [QuestionModel] = [QuestionModel]()
        //this is the loop that adds the filenames in to the questions array
        for fileName: String in directoryContents {
            questions.append(QuestionModel(fileName: fileName))
        }
        //order the elements in the questions array in ascnding order
        self.questions = questions.sort{$0.countryName.localizedCaseInsensitiveCompare($1.countryName) == NSComparisonResult.OrderedAscending}
    }
}