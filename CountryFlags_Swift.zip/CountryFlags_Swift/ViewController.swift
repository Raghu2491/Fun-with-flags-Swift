//
//  ViewController.swift
//  CountryFlags
//
//  Created by Raghavendra Jayaramegowda on 12/12/15.
//  Copyright © 2015 Raghavendra Jayaramegowda. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {
    
    @IBOutlet var answerTextField: UITextField!
    @IBOutlet var flagImageView: UIImageView!
    @IBOutlet var answerPicker: UIPickerView!
    
    var manager:QuestionsManager!
    var defaultBorderColor:CGColorRef!
    var currentIndex:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        answerPicker.dataSource = self
        answerPicker.delegate = self
        answerTextField.delegate = self
        let tapGestureRecognizer = UITapGestureRecognizer(target:self, action:Selector("didTapOnFlag:"))
        self.flagImageView.userInteractionEnabled = true
        self.flagImageView.addGestureRecognizer(tapGestureRecognizer)
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "didTapBackground:")
        self.answerTextField.addGestureRecognizer(tap)

        // Do any additional setup after loading the view.
        self.answerTextField.rightViewMode = .Always
        self.defaultBorderColor = self.answerTextField.layer.borderColor!
        self.manager = QuestionsManager.sharedInstance
        self.manager.loadQuestionsData()
        self.nextQuestion()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //randomly get question
    func nextQuestion() {
        if manager.questions.count < 1 {
            return
        }
        self.currentIndex = Int(arc4random_uniform(UInt32(manager.questions.count - 1)))
        self.updateQuestionLayout()
    }
    //Set default values
    func clearLayout() {
        self.flagImageView.image = nil
        self.answerTextField.text = nil
        self.clearAnswerIndicating()
        self.answerTextField.resignFirstResponder()
        self.answerPicker.selectRow(0, inComponent: 0, animated: false)
    }
    //set default colors
    func clearAnswerIndicating() {
        self.answerTextField.rightView = nil
        self.answerTextField.layer.borderColor = defaultBorderColor
        self.answerTextField.layer.borderWidth = 0.0
    }
    
    func updateQuestionLayout() {
        self.clearLayout()
        if self.currentIndex == -1 {
            return
        }
        let question: QuestionModel = manager.questions[self.currentIndex]
        let image: UIImage = UIImage(named: "Flags/\(question.fileName)")!//catpure field to get the image name
        self.flagImageView.image = image
        NSLog("%@", question.countryName)
    }
    
    func didTapOnFlag(sender: AnyObject) {
        self.nextQuestion()
    }
    //when tapped on back ground make sure keyboard does not appear
    func didTapBackground(sender: AnyObject) {
        self.answerTextField.resignFirstResponder()
        self.checkAnswer()
                self.answerTextField.resignFirstResponder()
    }
    
    func checkAnswer() {
        if ((self.answerTextField.text?.characters.count) == 0) {
            return
        }
        //if answer is correct then add green color to the border other wise add red color to the border
        let currentQuestion: QuestionModel = manager.questions[self.currentIndex]
        if currentQuestion.countryName.caseInsensitiveCompare(self.answerTextField.text!) == NSComparisonResult.OrderedSame {
            self.answerTextField.rightView = UIImageView(image: UIImage(named: "Ok"))
            self.answerTextField.layer.borderColor = UIColor.greenColor().CGColor
        }
        else {
            self.answerTextField.rightView = UIImageView(image: UIImage(named: "Cancel"))
            self.answerTextField.layer.borderColor = UIColor.redColor().CGColor
        }
        self.answerTextField.layer.borderWidth = 1.0
    }
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return manager.questions.count + 1
    }
    //returns the country name selected in the picker view
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if row == 0 {
            return "--- Select country ---"
        }
        return manager.questions[row - 1].countryName
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        var question: QuestionModel? = nil
        if row > 0 {
            question = manager.questions[row - 1] 
        }
        self.answerTextField.text = question!.countryName
        self.answerTextField.resignFirstResponder()
        self.checkAnswer()
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        self.checkAnswer()
        return true
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.answerTextField.endEditing(true)
        self.checkAnswer()
    }
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        self.clearAnswerIndicating()
        return true
    }
}